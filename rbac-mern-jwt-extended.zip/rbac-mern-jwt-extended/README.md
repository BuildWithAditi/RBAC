# MERN RBAC Extended (JWT) — Custom CSS
Features:
- Roles: admin, manager, user
- Posts: create/edit/delete (admin), create/edit-own (manager), view-only (user)
- Image uploads (multer + static /uploads)
- Comments (add, delete own or admin)
- Likes (toggle)
- Notifications (post created, liked, commented)
- Activity logs (key actions; admin sees all, others see own)

## Run
### Server
cd server
cp .env.example .env
npm install
npm run dev

### Client
cd client
npm install
npm run dev

Client: http://localhost:5173
Server: http://localhost:4000
